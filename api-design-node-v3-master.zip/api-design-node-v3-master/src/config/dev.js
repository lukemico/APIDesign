export const config = {
  secrets: {
    jwt: 'learneverything'
  },
  dbUrl: 'mongodb://localhost:27017/api-design'
}
