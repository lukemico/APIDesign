import { start } from './server'
start()
