import { crudControllers } from '../../utils/crud'
import { List } from './list.model'

export default crudControllers(List)
